
config.forEach(function (configuracoes) {
  configuracoes.listaMensagens = [];
  configuracoes.nomeDaPessoa = '';
})

class App extends React.Component {
  state = {
    numberOfScreens: config.length,
    lastId: 0,
    data: {},
    serverResponse: {}
  }

  handleAuthorize = () => {
    const motivo = prompt('Por que você liberou?')
  }

  handleClick = () => {
    fetch(`http://${hostnameDoServidor}:${portaDoServidor}/servidorCatracaIF/liberar/logCatraca/${this.state.data.id}`)
      .then(res => res.json())
      .then(data => {


        const date = new Date()
        const time = date.toLocaleTimeString(navigator.language, {
          hour: '2-digit',
          minute: '2-digit'
        })

        this.setState({
          data,
          serverResponse: JSON.parse(data.liberaCatracaComando)
        }, () => {
          config.forEach(configuracao => {
            if (configuracao.filtro.includes(this.state.serverResponse.nomeCatraca.toLowerCase())) {
              const style = {
                color: `${this.state.serverResponse && this.state.serverResponse.sentidoHorarioLiberado || this.state.serverResponse && this.state.serverResponse.sentidoAntiHorarioLiberado
                  ? 'green' : 'red'}`
              }

              configuracao.nomeDaPessoa = this.state.serverResponse.usuarioNome

              configuracao.listaMensagens.unshift(
                <p style={style}>
                  {time} -
                      <a
                    style={{
                      color: 'inherit',
                      textDecoration: 'none'
                    }}
                    href={enderecoDoCliente}
                  >
                    {this.state.serverResponse.usuarioId}
                  </a>
                  - <a
                    style={{
                      color: 'inherit',
                      textDecoration: 'none'
                    }}
                    href={enderecoDoCliente}
                  >
                    {this.state.serverResponse.usuarioNome}
                  </a>

                  <br />

                  Mensagem: {this.state.serverResponse.msgRecepcao || ''}
                </p>
              )
            }
          })

        })


        // const date = new Date()
        // const time = date.toLocaleTimeString(navigator.language, {
        //   hour: '2-digit',
        //   minute: '2-digit'
        // })

        // this.setState({
        //   data,
        //   serverResponse: JSON.parse(data.liberaCatracaComando)
        // }, () => {
        //   const style = {
        //     color: `${this.state.serverResponse && this.state.serverResponse.sentidoHorarioLiberado || this.state.serverResponse && this.state.serverResponse.sentidoAntiHorarioLiberado
        //       ? 'green' : 'red'}`
        //   }

        //   listaMensagens.unshift(
        //     <p style={style}>
        //       {time} -
        //       <a href={enderecoDoCliente}>
        //         {this.state.serverResponse.usuarioId}
        //       </a>
        //       - <a href={enderecoDoCliente}>
        //         {this.state.serverResponse.usuarioNome}
        //       </a>
        //     </p>
        // )
        // })
      })
  }

  componentDidMount() {
    setInterval(() => {
      fetch(`http://${hostnameDoServidor}:${portaDoServidor}/servidorCatracaIF/logCatraca/ultimoId`)
        .then(res => res.json())
        .then(lastId => {
          if (this.state.lastId === lastId) {
            return null
          }

          fetch(`http://${hostnameDoServidor}:${portaDoServidor}/servidorCatracaIF/logCatraca/${lastId}`)
            .then(res => res.json())
            .then(data => {
              const date = new Date()
              const time = date.toLocaleTimeString(navigator.language, {
                hour: '2-digit',
                minute: '2-digit'
              })

              this.setState({
                data,
                serverResponse: JSON.parse(data.liberaCatracaComando)
              }, () => {
                config.forEach(configuracao => {
                  if (configuracao.filtro.includes(this.state.serverResponse.nomeCatraca.toLowerCase())) {
                    const style = {
                      color: `${this.state.serverResponse && this.state.serverResponse.sentidoHorarioLiberado || this.state.serverResponse && this.state.serverResponse.sentidoAntiHorarioLiberado
                        ? 'green' : 'red'}`
                    }

                    configuracao.nomeDaPessoa = this.state.serverResponse.usuarioNome

                    configuracao.listaMensagens.unshift(
                      <p style={style}>
                        {time} -
                      <a
                          style={{
                            color: 'inherit',
                            textDecoration: 'none'
                          }}
                          href={enderecoDoCliente}
                        >
                          {this.state.serverResponse.usuarioId}
                        </a>
                        - <a
                          style={{
                            color: 'inherit',
                            textDecoration: 'none'
                          }}
                          href={enderecoDoCliente}
                        >
                          {this.state.serverResponse.usuarioNome}
                        </a>

                        <br />

                        Mensagem: {this.state.serverResponse.msgRecepcao || ''}
                      </p>
                    )
                  }
                })

                this.setState({ lastId })

              })
            })
            .catch(error => console.log(error))
        })
        .catch(error => console.log(error))
    }, 500)
  }

  render() {
    const { data, numberOfScreens, serverResponse, lastId } = this.state

    if (!data) {
      return <p>Carregando...</p>
    } else {
      return (
        <div className="flex-parent">
          {config.map(screenConfig => (
            <div
              style={{
                fontFamily: `"${screenConfig.fonte}", sans-serif`,
                fontSize: screenConfig.tamanhoDaFonte,
                backgroundColor: screenConfig.corDoFundo
              }}
            >
              <div
                className="access-control"
                style={{
                  width: `calc(99.9vw / ${numberOfScreens}`,
                  border: `1px solid ${screenConfig.corDaBorda}`
                }}
              >
                <div
                  className="access-control__title"
                  style={{
                    width: `calc(99.9vw / ${numberOfScreens}`,
                    border: `1px solid ${screenConfig.corDaBorda}`,
                    fontSize: screenConfig.tamanhoDaFonte
                  }}
                >
                  <p>{screenConfig.titulo}</p>
                </div>
                <div className="access-control__photo">
                  <img src="./profile.png" alt="Foto" />
                </div>

                <div className="access-control__name"
                  style={{
                    color: `${serverResponse && serverResponse.sentidoHorarioLiberado || serverResponse && serverResponse.sentidoAntiHorarioLiberado
                      ? screenConfig.corSucesso : screenConfig.corFracasso}`
                  }}
                >
                  <p>{screenConfig.nomeDaPessoa}</p>
                </div>

                <div
                  style={{
                    color: `${serverResponse && serverResponse.sentidoHorarioLiberado || serverResponse && serverResponse.sentidoAntiHorarioLiberado
                      ? screenConfig.corSucesso : screenConfig.corFracasso}`
                  }}
                  className="access-control__text"
                >
                  {serverResponse && serverResponse.texto}
                </div>
                {console.log(this.state)}

                {(lastId !== 0 && !serverResponse.sentidoHorarioLiberado && lastId !== 0 && !serverResponse.sentidoAntiHorarioLiberado) && (
                  <button
                    onClick={this.handleClick}
                    className="access-control__button"
                    style={{
                      border: `1px solid ${screenConfig.corDaBorda}`,
                      fontSize: screenConfig.tamanhoDaFonte
                    }}
                  >
                    LIBERAR
                </button>
                )}
              </div>

              <div
                className="output-message"
                style={{
                  border: `1px solid ${screenConfig.corDaBorda}`,
                  backgroundColor: screenConfig.corDoFundo
                }}
              >
                {screenConfig.listaMensagens.map(mensagem => <div>{mensagem}</div>)}
              </div>
              <div
                className="status-bar"
                style={{ width: `calc(99.9vw) / ${numberOfScreens}` }}
              >
                <button
                  style={{
                    color: 'yellow',
                  }}
                  onClick={this.handleAuthorize}
                >
                  Liberar {screenConfig.titulo}
                </button>
              </div>
            </div>
          ))}

        </div>
      )
    }
  }
}

ReactDOM.render(<App />, document.getElementById('root'));
